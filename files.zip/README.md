# 🌌 THE VOID — Anonymous Chat Platform

A fully anonymous, real-time chat platform. No sign-up, no login, no tracking.
Built with pure Node.js — **zero external dependencies**.

---

## 🚀 Quick Start

```bash
node server.js
```

Then open **http://localhost:3000** in any browser.

To change the port:
```bash
PORT=8080 node server.js
```

---

## ✨ Features

| Feature | Details |
|---|---|
| **Fully anonymous** | Random names like `SilentRaven492` assigned on arrival |
| **No sign-up** | Open the link and you're in |
| **Real-time** | WebSockets — messages appear instantly for everyone |
| **Live online counter** | Shows how many people are currently active |
| **Share link button** | One click to copy URL |
| **Join/leave notifications** | System messages when people enter/leave |
| **Message history** | Last 200 messages sent to new joiners |
| **Heartbeat** | Auto-reconnects if connection drops |
| **Zero dependencies** | Pure Node.js, no npm install needed |

---

## 🌐 Deploying for Public Access

### Option A — Railway (free tier)
1. Push to GitHub
2. Connect repo at https://railway.app
3. Deploy — Railway auto-detects Node.js

### Option B — Render (free tier)
1. Push to GitHub
2. New Web Service at https://render.com
3. Build command: *(leave empty)*
4. Start command: `node server.js`

### Option C — VPS / your own server
```bash
# Install Node.js, clone repo, then:
PORT=80 node server.js

# Or with PM2 for persistence:
npm install -g pm2
pm2 start server.js --name void-chat
pm2 save
```

### Option D — ngrok (quick local sharing)
```bash
node server.js &
npx ngrok http 3000
```
Share the ngrok URL with friends!

---

## 🏗 Architecture

```
Browser ←──WebSocket──→ server.js (Node.js)
                              │
                        Hand-rolled WS
                        (RFC 6455, no libs)
                              │
                        In-memory state:
                        - clients Map
                        - messageHistory[]
```

**server.js** handles:
- HTTP serving of `index.html`
- WebSocket upgrade (manual SHA-1 handshake)
- Frame parsing/building (masked client frames, unmasked server frames)
- Broadcast to all connected clients
- Message history (last 200, sent to new joiners)
- Ping/pong heartbeat every 25s

---

## 📁 Files

```
void-chat/
├── server.js     ← Node.js server (HTTP + WebSocket)
├── index.html    ← Frontend (served by server.js)
└── README.md     ← This file
```

No `package.json` dependencies required.
